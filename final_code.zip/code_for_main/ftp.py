﻿
from ftplib import FTP
import os
import sys
import time
import socket

class MyFTP:
    def __init__(self, host, port=21):
        self.host = host
        self.port = port
        self.ftp = FTP()
        self.ftp.encoding = 'gbk'
        self.log_file = open("log.txt", "a")
        self.file_list = []
    def login(self, username, password):
        try:
            timeout = 60
            socket.setdefaulttimeout(timeout)
            self.ftp.set_pasv(False)
            self.debug_print('OPEN LINE %s' % self.host)
            self.ftp.connect(self.host, self.port)
            self.debug_print('SUCCESS %s' % self.host)
            self.debug_print('LOGIN %s' % self.host)
            self.ftp.login(username, password)
            self.debug_print('LOGIN SUCCESS %s' % self.host)
            self.debug_print(self.ftp.welcome)
        except Exception as err:
            self.deal_error("FTP ERROR£ẃ%s" % err)
            pass

    def upload_file(self, local_file, remote_file):
        if not os.path.isfile(local_file):
            self.debug_print('%s UNEXIST' % local_file)
            return

        buf_size = 1024
        file_handler = open(local_file, 'rb')
        self.ftp.storbinary('STOR %s' % remote_file, file_handler, buf_size)
        file_handler.close()
        self.debug_print('UPLOAD: %s' % local_file + "SUCCESS!")

    def close(self):
        self.debug_print("close()---> FTP QUIT!!")
        self.ftp.quit()
        self.log_file.close()

    def debug_print(self, s):
        self.write_log(s)

    def deal_error(self, e):
        log_str = 'ERROR: %s' % e
        self.write_log(log_str)
        sys.exit()

    def write_log(self, log_str):
        time_now = time.localtime()
        date_now = time.strftime('%Y-%m-%d', time_now)
        format_log_str = "%s ---> %s \n " % (date_now, log_str)
        print(format_log_str)
        self.log_file.write(format_log_str)

    def get_file_list(self, line):
        file_arr = self.get_file_name(line)
        if file_arr[1] not in ['.', '..']:
            self.file_list.append(file_arr)

    def get_file_name(self, line):
        pos = line.rfind(':')
        while (line[pos] != ' '):
            pos += 1
        while (line[pos] == ' '):
            pos += 1
        file_arr = [line[0], line[pos:]]
        return file_arr

if __name__ == "__main__":
    my_ftp = MyFTP("47.93.28.66")
    my_ftp.login("root", "ZJLzjl123")
    my_ftp.upload_file("out.png", "/out.png")
    my_ftp.upload_file("endtime_data.txt", "/endtime_data.txt")
    my_ftp.upload_file("begintime_data.txt", "/begintime_data.txt")
    my_ftp.close()
