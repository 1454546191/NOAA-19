﻿import ephem
import time,datetime
import os,sys
import requests
import socket
from ftplib import FTP
me_city = ephem.Observer()
me_city.lon, me_city.lat, me_city.elevation ='116.44752477', '39.65736782', 50.0
#location

url = "http://www.amsat.org/amsat/ftp/keps/current/nasabare.txt"
get = requests.get(url).text
start = get.find("NOAA-19")
def getline(data,data_number):
	line=[]
	i=data_number
	while data[i]!='\n':
		line.append(data[i])
		i=i+1
	return "".join(line)
tle_1=getline(get,start)
tle_2=getline(get,start+8)
tle_3=getline(get,start+78)
#TLE
sat = ephem.readtle(tle_1, tle_2, tle_3)

#control
def run_radio(run_time):
	os.system("python3 radio_control.py"+" "+str(run_time))

def run_decode():
	os.system("python3 NOAA.py")

def run_ftp():
	os.system("python3 ftp.py")


#calculate in_zone_time
def inzone_time(now_time,max_predict_time,z_yvzhi):#return seconds
	step_t = datetime.timedelta(seconds=1)
	radio_seconds = 0
	pre_now = now_time
	for i in range(0,max_predict_time):
		pre_now = pre_now+step_t
		pre_time = ephem.Date(pre_now)
		me_city.date = pre_time
		sat.compute(me_city)
		z = sat.alt * 180.0 / 3.1416
		if z>z_yvzhi :
			radio_seconds=radio_seconds+1
		else:
			break
	
	return radio_seconds
#max 1200 run time<1s

def write_endtime_txt(time):
	time_str = str(time)
	with open('endtime_data.txt','w') as f:
		f.write(time_str)
def write_begintime_txt(time):
	time_str = str(time)
	with open('begintime_data.txt','w') as f:
		f.write(time_str)

max_predict_time = 1200 #seconds 20*60
z_yvzhi = 2
while True:
	now_time=datetime.datetime.utcnow()
	now_time2 = ephem.Date(now_time)
	me_city.date = now_time2
	sat.compute(me_city)
	z0 = sat.alt * 180.0 / 3.1416
	radio_seconds = 0
	if z0 >0 :
		radio_seconds=inzone_time(now_time,max_predict_time,z_yvzhi)
	if radio_seconds >600 :
		print(radio_seconds)
		now_time3=datetime.datetime.utcnow()
		time_w=now_time3+datetime.timedelta(seconds=radio_seconds)
		time_w2=ephem.Date(time_w)
		time_w3=now_time3+datetime.timedelta(seconds=25)
		time_w4=ephem.Date(time_w3)
		write_endtime_txt(time_w2)
		write_begintime_txt(time_w4)
		run_radio(radio_seconds)#run over to continue
		time.sleep(5)#to avoid the error, you can del it
		run_decode()
		time.sleep(5)
		run_ftp()	
		
	




