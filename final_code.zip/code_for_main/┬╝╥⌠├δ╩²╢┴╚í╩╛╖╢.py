import time
import sys
t = int(sys.argv[1])
#print(t)
#print(type(t))
for d in range(0,int(t)):
	print("hello")
	#time.sleep(1)
	d=d-1
