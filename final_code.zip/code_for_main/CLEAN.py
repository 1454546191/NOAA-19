import RPi.GPIO as gpio
import time
gpio.setmode(gpio.BCM)
#IN1:6,IN2:13,IN3:19,IN4:26
gpio.setup(6,gpio.OUT)
gpio.setup(13,gpio.OUT)
gpio.setup(19,gpio.OUT)
gpio.setup(26,gpio.OUT)
gpio.output(6,gpio.LOW)
gpio.output(13,gpio.LOW)
gpio.output(19,gpio.LOW)
gpio.output(26,gpio.LOW)
gpio.cleanup()