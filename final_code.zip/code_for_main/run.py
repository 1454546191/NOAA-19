import RPi.GPIO as gpio
import time
import ephem
gpio.setmode(gpio.BCM)
#IN1:6,IN2:13,IN3:19,IN4:26
gpio.setup(6,gpio.OUT)
gpio.setup(13,gpio.OUT)
gpio.setup(19,gpio.OUT)
gpio.setup(26,gpio.OUT)
gpio.output(6,gpio.LOW)
gpio.output(13,gpio.LOW)
gpio.output(19,gpio.LOW)
gpio.output(26,gpio.LOW)
me_city = ephem.Observer()
me_city.lon, me_city.lat, me_city.elevation ='116.44752477', '39.65736782', 50.0
#location
def getline(data,data_number):
	line=[]
	i=data_number
	while data[i]!='\n':
		line.append(data[i])
		i=i+1
	return "".join(line)
TEMP_XY = 0.0
TEMP_Z = 0.0
url = "http://www.amsat.org/amsat/ftp/keps/current/nasabare.txt"
while True:
	get = requests.get(url).text
	start = get.find("NOAA-19")
	tle_1=getline(get,start)
	tle_2=getline(get,start+8)
	tle_3=getline(get,start+78)
	#TLE
	sat = ephem.readtle(tle_1, tle_2, tle_3)
	me_city.date = ephem.now()
	#calculate time
	sat.compute(me_city)
	xy = sat.az * 180.0 / 3.1416
	z = sat.alt * 180.0 / 3.1416
	print(xy)
	print(z)
	if z>=0:
		#60 DEGREE PER SECOND
		motor1_time = (xy-TEMP_XY)/60
		motor2_time = (z-TEMP_Z)/60
		print(motor1_time)
		print(motor2_time)
		if  motor1_time<=0:
			gpio.output(6,gpio.HIGH)# RE TIME CYCLE left
			gpio.output(13,gpio.LOW)
			time.sleep(-motor1_time)
		else:
			gpio.output(6,gpio.LOW)#right
			gpio.output(13,gpio.HIGH)
			time.sleep(motor1_time)
		gpio.output(6,gpio.LOW)
		gpio.output(13,gpio.LOW)	
		if  motor2_time<=0:
			gpio.output(19,gpio.HIGH)#down
			gpio.output(26,gpio.LOW)
			time.sleep(-motor2_time)
		else:
			gpio.output(19,gpio.LOW)
			gpio.output(26,gpio.HIGH)
			time.sleep(motor2_time)	
		gpio.output(19,gpio.LOW)
		gpio.output(26,gpio.LOW)	
		time.sleep(60)
		TEMP_XY =  xy
		TEMP_Z = z
	else:
		gpio.output(6,gpio.LOW)
		gpio.output(13,gpio.LOW)
		gpio.output(19,gpio.LOW)
		gpio.output(26,gpio.LOW)
		time.sleep(60)	
	
	

gpio.cleanup()