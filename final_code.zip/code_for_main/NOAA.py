import scipy.io.wavfile
import scipy.signal
import sys
import numpy
import skimage.morphology as morp
from skimage.filters import rank
from skimage import exposure
from PIL import Image
import ephem
import math
import os
import requests
import warnings

warnings.filterwarnings("ignore")
def resample(Sig,rate):  
    if rate != RATE:
        divisor=gcd(rate,RATE)
        interFactor=RATE/divisor
        extraFactor=rate/divisor
        #Sig=scipy.signal.resample_poly(Sig,interFactor,extraFactor,window=('kaiser',5.0))
        #Sig=scipy.signal.resample(Sig,interFactor,extraFactor,window=None)
        Sig=scipy.signal.resample_poly(Sig,interFactor,extraFactor)
    return Sig

def gcd(a,b):
    small=min(a,b)
    for i in range(1,small+1):
        if a%i==0 and b%i==0:
            m=i
    return m
    


'''
def resample(filename):
    (rate, signal) = scipy.io.wavfile.read(filename)
    if rate != RATE:
        coef = RATE / rate
        samples = int(coef * len(signal))
        signal = scipy.signal.resample(signal, samples)
        scipy.io.wavfile.write("resampled.wav", RATE, signal)
    return signal
'''

def histeq(image,n):
    m=int((n-1)/2)
    p=numpy.size(image,0)
    q=numpy.size(image,1)
    padding=numpy.pad(image,((m,m),(m,m)),'constant', constant_values=(0,0)) 
    localpro=numpy.zeros((n,n))
    for i in range(m,p-m+1):
        for j in range(m,q-m+1):
            part=padding[i-m:i+m+1,j-m:j+m+1]
            localpro=exposure.equalize_hist(part)*255
            image[i-m,j-m]=localpro[m,m]
    return image


def _digitize(signal, plow=0.5, phigh=99.5):
    '''
    Convert signal to numbers between 0 and 255.
    '''
    (low, high) = numpy.percentile(signal, (plow, phigh))
    delta = high - low
    data = numpy.round(255 * (signal - low) / delta)
    data[data < 0] = 0
    data[data > 255] = 255
    return data.astype(numpy.uint8)

def _reshape(signal):
    '''
    Find sync frames and reshape the 1D signal into a 2D image.
    Finds the sync A frame by looking at the maximum values of the cross
    correlation between the signal and a hardcoded sync A frame.
    The expected distance between sync A frames is 2080 samples, but with
    small variations because of Doppler effect.
    '''
    # sync frame to find: seven impulses and some black pixels (some lines
    # have something like 8 black pixels and then white ones)
    #syncA = [0, 128, 255, 128]*7 + [0]*7
    syncA=[11]*4+[244,244,11,11]*7+[11]*8
    # list of maximum correlations found: (index, value)
    peaks = [(0, 0)]
    # minimum distance between peaks
    mindistance = 2000
    # need to shift the values down to get meaningful correlation values
    signalshifted = [x-128 for x in signal]
    syncA = [x-128 for x in syncA]
    for i in range(len(signal)-len(syncA)):
        corr = numpy.dot(syncA, signalshifted[i : i+len(syncA)])
        # if previous peak is too far, keep it and add this value to the
        # list as a new peak
        if i - peaks[-1][0] > mindistance:
            peaks.append((i, corr))
        # else if this value is bigger than the previous maximum, set this
        # one
        elif corr > peaks[-1][1]:
            peaks[-1] = (i, corr)
    # create image matrix starting each line on the peaks found
    matrix = []
    for i in range(len(peaks) - 1):
        matrix.append(signal[peaks[i][0] : peaks[i][0] + 2080])
    return numpy.array(matrix)    

def getline(data,data_number):
    line=[]
    i=data_number
    while data[i]!='\n':
        line.append(data[i])
        i=i+1
    return "".join(line)



url="http://www.amsat.org/amsat/ftp/keps/current/nasabare.txt"
get = requests.get(url).text
start=get.find("NOAA-19")


line1=getline(get,start)
line2=getline(get,start+8)
line3=getline(get,start+78)
sat=ephem.readtle(line1,line2,line3)
#me.date=ephem.now()
#date=ephem.now()
start2=open("begintime_data.txt")
date1=start2.read()
#date1='2020/4/17 09:19:45'
start2.close()
sat.compute(date1)
lon1=sat.sublong/3.1415927*180
lat1=sat.sublat/3.1415927*180
h1= sat.elevation

end=open("endtime_data.txt")
date2=end.read()
#date2='2020/4/17 09:35:02'
end.close()
sat.compute(date2)
lon2=sat.sublong/3.1415927*180
lat2=sat.sublat/3.1415927*180
h2= sat.elevation

def distance(lat1,lon1,lat2,lon2):
    R = 6371.22
    dLat = (lat2-lat1) *math.pi / 180
    dLon = (lon2-lon1) * math.pi / 180
    dtheta=math.sqrt(dLat*dLat+dLon*dLon)
    d=R*dtheta
    return d

L=distance(lat1,lon1,lat2,lon2)

R=6371.22*1000
high=(h1+h2)/2

def location(img,i,j):
    (h,w)=img.shape
    band=(w-1)/2
    l=(h-j-1)/(h-1)*L*1000
    incline=99.197/180*math.pi
    alpha=55.37/180*math.pi
    if i!=band and j!=0 and j!=h-1:
        beta=math.atan((band-i)/band*math.tan(alpha))
        sigma=math.asin((high+R)/R*math.sin(beta))-beta
        delta=math.atan(math.tan(sigma)/math.sin(l/R))
        gamma=math.pi-delta-incline
        s=R*math.acos(math.cos(sigma)*math.cos(l/R))
        lat=math.asin(math.sin(s/R)*math.cos(lat1/180*math.pi)*math.cos(incline-math.pi/2+delta)+math.cos(s/R)*math.sin(lat1/180*math.pi))/math.pi*180
        lon=lon1-math.asin(math.sin(incline-math.pi/2+delta)*math.sin(s/R)/math.cos(lat*math.pi/180))*180/math.pi
    elif i==band:
        lat=math.asin(math.sin(l/R)*math.cos(lat1/180*math.pi)*math.cos(incline-math.pi/2)+math.cos(l/R)*math.sin(lat1/180*math.pi))/math.pi*180
        lon=lon1-math.asin(math.sin(incline-math.pi/2)*math.sin(l/R)/math.cos(lat*math.pi/180))*180/math.pi
    elif j==0:
        beta=math.atan((band-i)/band*math.tan(alpha))
        sigma=math.asin((high+R)/R*math.sin(beta))-beta
        lat=math.asin(math.sin(lat2/180*math.pi)*math.cos(sigma)+math.cos(lat2/180*math.pi)*math.sin(sigma)*math.cos(incline))/math.pi*180
        lon=lon2-math.asin(math.sin(incline)*math.sin(sigma)/math.cos(lat*math.pi/180))*180/math.pi
    else:
        beta=math.atan((band-i)/band*math.tan(alpha))
        sigma=math.asin((high+R)/R*math.sin(beta))-beta
        lat=math.asin(math.sin(lat1/180*math.pi)*math.cos(sigma)+math.cos(lat1/180*math.pi)*math.sin(sigma)*math.cos(incline))/math.pi*180
        lon=lon1-math.asin(math.sin(incline)*math.sin(sigma)/math.cos(lat*math.pi/180))*180/math.pi
    return lon,lat

    

RATE = 20800
File = "2020.wav"
outfile = "out.png"
(rate,Sig) = scipy.io.wavfile.read(File)
originsig=Sig
step=3*rate*60
for i in range(0,len(originsig),step):
    Sig=originsig[i:i+step]
    Sig = resample(Sig,rate)
    truncate = RATE * int(len(Sig) // RATE)
    Sig = Sig[:truncate]
    hilbert = scipy.signal.hilbert(Sig)
    filtered = scipy.signal.medfilt(numpy.abs(hilbert), 5)
    reshaped = filtered.reshape(len(filtered) // 5, 5)
    digitized = _digitize(reshaped[:, 3])
    matrix = _reshape(digitized)
    if i==0:
        picmat=matrix
    else:
        picmat=numpy.vstack((picmat,matrix))

# matrix = numpy.flip(matrix,0)
# matrix = numpy.flip(matrix,1)
# #matrix =  histeq(matrix,25)
# image = Image.fromarray(matrix)
# image.save(outfile)
# image.show()

picmat= numpy.flip(picmat,0)
picmat = numpy.flip(picmat,1)
#matrix =  histeq(matrix,25)
part=picmat[:,45:954]
eps=0.02
(h,w)=part.shape
for i in range(w):
    for j in range (h):
        (lon,lat)=location(part,i,j)
        #longitude[j,i]=lon
        #latitude[j,i]=lat
        if lon%10<=eps or lat%10<=eps:
            part[j,i]=0
picmat[:,45:954]=part

image = Image.fromarray(picmat)
image.save(outfile)
#image.show()
