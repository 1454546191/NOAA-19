import RPi.GPIO as gpio
import time
gpio.setmode(gpio.BCM)
#IN1:6,IN2:13,IN3:19,IN4:26
gpio.setup(6,gpio.OUT)
gpio.setup(13,gpio.OUT)
gpio.setup(19,gpio.OUT)
gpio.setup(26,gpio.OUT)
gpio.output(6,gpio.LOW)
gpio.output(13,gpio.LOW)
gpio.output(19,gpio.LOW)
gpio.output(26,gpio.LOW)

xy = input("XY initialize degree (left:-):")
xy = int(xy)
if xy<=0:
	gpio.output(6,gpio.HIGH)
	gpio.output(13,gpio.LOW)
	time.sleep(-xy/60)
else:
	gpio.output(6,gpio.LOW)
	gpio.output(13,gpio.HIGH)
	time.sleep(xy/60)
gpio.output(6,gpio.LOW)
gpio.output(13,gpio.LOW)


z = input("Z initialize degree (down:-):")
z = int(z)
if z<=0:
	gpio.output(19,gpio.HIGH)
	gpio.output(26,gpio.LOW)
	time.sleep(-z/60)
else:
	gpio.output(19,gpio.LOW)
	gpio.output(26,gpio.HIGH)
	time.sleep(z/60)
gpio.output(19,gpio.LOW)
gpio.output(26,gpio.LOW)

gpio.cleanup()