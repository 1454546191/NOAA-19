from multiprocessing import Process
import os
import  time
import sys
t = int(sys.argv[1])
def run_proc():
        os.system("python radio.py")

if __name__=='__main__':
	print('Parent process %s.' % os.getpid())
	p = Process(target=run_proc)
	print('Child process will start.')
	p.start()
	time.sleep(t)
	os.system('pkill -f "radio.py"')
	p.terminate()
	print('Child process end.')

